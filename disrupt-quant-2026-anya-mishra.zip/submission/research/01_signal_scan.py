import pandas as pd, numpy as np
from scipy import stats

d = pd.read_csv('data/development.csv', parse_dates=['date']).sort_values(['date','asset_id'])

# ---- build forward targets -------------------------------------------------
# Decision at close t -> execute at open t+1 -> new position earns open->close of t+1.
# A position already held also earns close t -> open t+1 (the gap).
piv = lambda c: d.pivot(index='date', columns='asset_id', values=c)
close, open_ = piv('close'), piv('open')

fwd_oc = (close.shift(-1) / open_.shift(-1) - 1)     # tradeable for a NEW position
fwd_cc = (close.shift(-1) / close - 1)               # earned by a HELD position
fwd_gap = (open_.shift(-1) / close - 1)              # overnight gap only

# cross-sectionally demean: these are relative-value signals
def demean(x): return x.sub(x.mean(axis=1), axis=0)

targets = {'open->close t+1': fwd_oc, 'close->close t+1': fwd_cc, 'overnight gap': fwd_gap}

features = ['return_1d','return_5d','return_20d','price_strength_20','price_strength_60',
            'realized_vol_5d','realized_vol_20d','volume_zscore','volume_trend',
            'sentiment_score','liquidity_score','flow_index','carry_score',
            'event_intensity','event_flag','intraday_range','spread_bps','sector_dispersion']

def ic_table(target):
    rows = []
    ty = demean(target)
    for f in features:
        X = piv(f)
        ics = []
        for dt in X.index[:-1]:
            a, b = X.loc[dt], ty.loc[dt]
            m = a.notna() & b.notna()
            if m.sum() > 5 and a[m].nunique() > 2:
                ics.append(stats.spearmanr(a[m], b[m]).statistic)
        ics = np.array(ics, float); ics = ics[np.isfinite(ics)]
        t = ics.mean()/(ics.std(ddof=1)/np.sqrt(len(ics)))
        rows.append({'feature': f, 'mean_IC': ics.mean(), 't_stat': t,
                     'IC_IR_ann': ics.mean()/ics.std(ddof=1)*np.sqrt(252),
                     'hit': (ics>0).mean()})
    return pd.DataFrame(rows).sort_values('t_stat', key=abs, ascending=False)

for name, tgt in targets.items():
    print('='*78); print('TARGET:', name)
    print(ic_table(tgt).to_string(index=False, float_format=lambda x: f'{x:8.4f}'))
