import pandas as pd, numpy as np
from scipy import stats
import warnings; warnings.filterwarnings('ignore')

d = pd.read_csv('data/development.csv', parse_dates=['date']).sort_values(['date','asset_id'])
piv = lambda c: d.pivot(index='date', columns='asset_id', values=c)
close, open_ = piv('close'), piv('open')
fwd = (close.shift(-1)/open_.shift(-1) - 1)
fwdx = fwd.sub(fwd.mean(axis=1), axis=0)          # cross-sectionally demeaned

def daily_ic(X, Y):
    out = {}
    for dt in X.index[:-1]:
        a, b = X.loc[dt], Y.loc[dt]
        m = a.notna() & b.notna()
        if m.sum() > 5: out[dt] = stats.spearmanr(a[m], b[m]).statistic
    return pd.Series(out)

print('### 1. YEARLY STABILITY of mean IC (target = open->close t+1, demeaned)\n')
top = ['return_1d','carry_score','return_5d','return_20d','event_intensity','sentiment_score','flow_index']
tab = {}
for f in top:
    ic = daily_ic(piv(f), fwdx)
    tab[f] = ic.groupby(ic.index.year).mean()
print(pd.DataFrame(tab).T.to_string(float_format=lambda x: f'{x:7.4f}'))

print('\n### 2. QUINTILE SPREADS, bps/day (long top quintile, short bottom)\n')
for f in ['return_1d','carry_score','return_5d','return_20d']:
    X = piv(f); r = X.rank(axis=1, pct=True)
    lo, hi = (r <= .2), (r >= .8)
    spread = (fwdx.where(hi).mean(axis=1) - fwdx.where(lo).mean(axis=1)).dropna()
    sign = -1 if f.startswith('return_') and f != 'return_20d' else 1
    s = spread*sign
    print(f'{f:16s} sign={sign:+d}  {s.mean()*1e4:6.2f} bps/day  '
          f't={s.mean()/(s.std()/np.sqrt(len(s))):5.2f}  '
          f'ann.Sharpe={s.mean()/s.std()*np.sqrt(252):5.2f}')

print('\n### 3. MONOTONICITY across quintiles, bps/day\n')
for f in ['return_1d','carry_score']:
    X = piv(f); r = X.rank(axis=1, pct=True); out=[]
    for q in range(5):
        m = (r > q*.2) & (r <= (q+1)*.2 + (1e-9 if q==4 else 0))
        out.append(fwdx.where(m).mean(axis=1).mean()*1e4)
    print(f'{f:16s} Q1..Q5: ' + '  '.join(f'{v:6.2f}' for v in out))

print('\n### 4. MACRO / TIME-SERIES signals vs next-day EQUAL-WEIGHT MARKET return\n')
mkt = fwd.mean(axis=1)
for f in ['macro_factor_1','macro_factor_2','macro_factor_3','market_volatility','market_return']:
    s = d.groupby('date')[f].first()
    x, y = s.iloc[:-1], mkt.iloc[:-1]
    m = x.notna() & y.notna()
    sl = stats.linregress(x[m], y[m])
    print(f'{f:18s} corr={np.corrcoef(x[m],y[m])[0,1]:+.4f}  t={sl.slope/sl.stderr:+6.2f}')

print('\n### 5. IS 1d-REVERSAL A MICROSTRUCTURE ARTIFACT? IC by return definition\n')
for lbl, tgt in [('open->close t+1 (tradeable)', fwd), ('close->close t+1', close.shift(-1)/close-1),
                 ('close->close t+2 (skip a day)', close.shift(-2)/close.shift(-1)-1)]:
    t = tgt.sub(tgt.mean(axis=1), axis=0)
    ic = daily_ic(piv('return_1d'), t)
    print(f'  {lbl:32s} meanIC={ic.mean():+.4f}  t={ic.mean()/(ic.std()/np.sqrt(len(ic))):+5.2f}')
