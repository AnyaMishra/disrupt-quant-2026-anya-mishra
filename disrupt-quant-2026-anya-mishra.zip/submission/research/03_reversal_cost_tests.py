import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
d = pd.read_csv('data/development.csv', parse_dates=['date']).sort_values(['date','asset_id'])
P = lambda c: d.pivot(index='date', columns='asset_id', values=c)
close,open_,spr,vol20,liq,volu = P('close'),P('open'),P('spread_bps'),P('realized_vol_20d'),P('liquidity_score'),P('volume')
fwd = close.shift(-1)/open_.shift(-1)-1
fwdx = fwd.sub(fwd.mean(axis=1),axis=0)
NAV = 1e6

def evaluate(w, label):
    """w: weights indexed by decision date. Full cost model incl. sqrt impact."""
    w = w.fillna(0.0)
    dlt = w.diff().fillna(w.iloc[0:1].reindex(w.index).fillna(0))
    part = (dlt.abs()*NAV/(volu*close)).clip(lower=0)
    impact = 0.10*vol20*np.sqrt(part)/np.sqrt(liq.clip(.1,1.))
    cost = (dlt.abs()*(spr/20000 + impact)).sum(axis=1)
    gross = (w*fwdx).sum(axis=1)
    net = (gross-cost).dropna()
    return dict(label=label, gross_bps=gross.mean()*1e4, cost_bps=cost.mean()*1e4,
                net_bps=net.mean()*1e4, turn=dlt.abs().sum(axis=1).mean(),
                sharpe=net.mean()/net.std()*np.sqrt(252))

def zs(X): return X.sub(X.mean(axis=1),axis=0).div(X.std(axis=1),axis=0)
def unit(W): return W.div(W.abs().sum(axis=1),axis=0).fillna(0)   # gross = 1

rev, car = -zs(P('return_1d')), zs(P('carry_score'))

# internal chronological split: fit on 2021-2022, check on 2023+
TR = slice(None,'2022-12-31'); TE = slice('2023-01-01',None)
def rep(w,label):
    for nm,sl in [('train 21-22',TR),('test 23-24',TE)]:
        r = evaluate(w.loc[sl], f'{label} [{nm}]')
        print(f"  {r['label']:44s} gross{r['gross_bps']:6.2f} cost{r['cost_bps']:6.2f} "
              f"NET{r['net_bps']:+6.2f} turn{r['turn']:5.2f} SR{r['sharpe']:+6.2f}")

print('A. BASELINES'); rep(unit(rev),'reversal, all 24, z-weighted'); rep(unit(car),'carry, all 24, z-weighted')

print('\nB. REVERSAL: tail-only (alpha is concentrated in extremes)')
for k in [2,3,4,6,8]:
    r = rev.rank(axis=1)
    W = pd.DataFrame(0., index=rev.index, columns=rev.columns)
    W[r>24-k] = 1.; W[r<=k] = -1.
    rep(unit(W), f'reversal, long/short top-bottom {k}')

print('\nC. REVERSAL: cost-aware (divide signal by expected one-way spread cost)')
for k in [3,4,6]:
    score = rev/(spr/20000)
    r = score.rank(axis=1)
    W = pd.DataFrame(0., index=rev.index, columns=rev.columns)
    W[r>24-k]=1.; W[r<=k]=-1.
    rep(unit(W), f'cost-adjusted reversal, top-bottom {k}')

print('\nD. REVERSAL: no-trade band (only rebalance if |delta| > b)')
base = unit(rev)
for b in [0.02,0.04,0.06]:
    W = base.copy().values; out = np.zeros_like(W); prev = np.zeros(W.shape[1])
    for i in range(len(W)):
        tgt = W[i].copy(); move = np.abs(tgt-prev)>b
        newp = np.where(move, tgt, prev); out[i]=newp; prev=newp
    rep(pd.DataFrame(out,index=base.index,columns=base.columns), f'reversal + no-trade band {b}')
