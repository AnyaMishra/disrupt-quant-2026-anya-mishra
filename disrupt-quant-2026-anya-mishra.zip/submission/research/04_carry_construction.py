import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
d = pd.read_csv('data/development.csv', parse_dates=['date']).sort_values(['date','asset_id'])
P = lambda c: d.pivot(index='date', columns='asset_id', values=c)
close,open_,spr,vol20,liq,volu = P('close'),P('open'),P('spread_bps'),P('realized_vol_20d'),P('liquidity_score'),P('volume')
fwd = close.shift(-1)/open_.shift(-1)-1; fwdx = fwd.sub(fwd.mean(axis=1),axis=0)
sect = d.groupby('asset_id').sector.first()
NAV=1e6
def zs(X): return X.sub(X.mean(axis=1),axis=0).div(X.std(axis=1),axis=0)
def unit(W,g=1.0): return (W.div(W.abs().sum(axis=1),axis=0)*g).fillna(0)
def sector_neutral(S):
    out = S.copy()
    for s in sect.unique():
        c = sect[sect==s].index
        out[c] = S[c].sub(S[c].mean(axis=1),axis=0)
    return out
def ev(w,sl):
    w=w.loc[sl].fillna(0); dlt=w.diff().fillna(w.iloc[0:1].reindex(w.index).fillna(0))
    part=(dlt.abs()*NAV/(volu*close)).clip(lower=0)
    cost=(dlt.abs()*(spr/20000+0.10*vol20*np.sqrt(part)/np.sqrt(liq.clip(.1,1.)))).sum(axis=1)
    net=((w*fwdx).sum(axis=1)-cost).dropna()
    return net.mean()*1e4, net.mean()/net.std()*np.sqrt(252), dlt.abs().sum(axis=1).mean()
TR=slice(None,'2022-12-31'); TE=slice('2023-01-01',None)
def rep(w,l):
    a=ev(w,TR); b=ev(w,TE)
    print(f'  {l:38s} train NET{a[0]:+5.2f} SR{a[1]:+5.2f} | test NET{b[0]:+5.2f} SR{b[1]:+5.2f} | turn{b[2]:5.3f}')

car = zs(P('carry_score'))
print('A. WEIGHTING SCHEME (gross 1.0, dollar-neutral)')
rep(unit(car),'z-score weights')
rep(unit(zs(P('carry_score').rank(axis=1))),'rank weights')
rep(unit(car.clip(-1.5,1.5)),'z clipped at +/-1.5')
rep(unit(car/vol20),'z / realized_vol_20d (risk parity)')
rep(unit(sector_neutral(car)),'sector-neutral z')
rep(unit(sector_neutral(car)/vol20),'sector-neutral z / vol')

print('\nB. DOES CARRY WORK WITHIN OR ACROSS SECTORS?')
from scipy import stats
for lbl,S in [('raw carry',car),('sector-neutral carry',sector_neutral(car)),
              ('sector-mean carry only',car-sector_neutral(car))]:
    ics=[stats.spearmanr(S.loc[t].dropna(), fwdx.loc[t].reindex(S.loc[t].dropna().index)).statistic
         for t in S.index[:-1]]
    ics=np.array([i for i in ics if np.isfinite(i)])
    print(f'  {lbl:26s} meanIC{ics.mean():+.4f} t={ics.mean()/(ics.std()/np.sqrt(len(ics))):+5.2f}')

print('\nC. SMOOTHING carry (does averaging the signal help or hurt?)')
for h in [1,5,20,60]:
    rep(unit(zs(P('carry_score').rolling(h,min_periods=1).mean())), f'carry EMA/SMA window {h}')

print('\nD. GROSS EXPOSURE SCALING (test period)')
for g in [0.5,1.0,1.5,2.0]:
    n,s,t = ev(unit(sector_neutral(car)/vol20, g), TE)
    print(f'  gross {g:4.2f}  NET {n:+5.2f} bps/d  SR {s:+5.2f}  turnover {t:5.3f}')
