import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
from scipy import stats
d = pd.read_csv('data/development.csv', parse_dates=['date']).sort_values(['date','asset_id'])
P = lambda c: d.pivot(index='date', columns='asset_id', values=c)
close,open_,spr,vol20,liq,volu = P('close'),P('open'),P('spread_bps'),P('realized_vol_20d'),P('liquidity_score'),P('volume')
fwd = close.shift(-1)/open_.shift(-1)-1; fwdx = fwd.sub(fwd.mean(axis=1),axis=0)
sect = d.groupby('asset_id').sector.first(); NAV=1e6
def zs(X): return X.sub(X.mean(axis=1),axis=0).div(X.std(axis=1),axis=0)
def sn(S):
    o=S.copy()
    for s in sect.unique():
        c=sect[sect==s].index; o[c]=S[c].sub(S[c].mean(axis=1),axis=0)
    return o
def build(win=20, gross=1.0):
    raw = P('carry_score').rolling(win, min_periods=1).mean()
    S = sn(zs(raw))/vol20
    return (S.div(S.abs().sum(axis=1),axis=0)*gross).fillna(0)
def netret(w, sl=slice(None)):
    w=w.loc[sl]; dlt=w.diff().fillna(w.iloc[0:1].reindex(w.index).fillna(0))
    part=(dlt.abs()*NAV/(volu*close)).clip(lower=0)
    cost=(dlt.abs()*(spr/20000+0.10*vol20*np.sqrt(part)/np.sqrt(liq.clip(.1,1.)))).sum(axis=1)
    return ((w*fwdx).sum(axis=1)-cost).dropna()

W = build()
r = netret(W)
print(f'FULL DEV: net {r.mean()*1e4:+.2f} bps/d  Sharpe {r.mean()/r.std()*np.sqrt(252):+.2f}  '
      f'ann.ret {(1+r).prod()**(252/len(r))-1:.2%}  vol {r.std()*np.sqrt(252):.2%}')

print('\n1. SMOOTHING-WINDOW SENSITIVITY (is the result knife-edge?)')
for w_ in [1,3,5,10,20,40,60,90]:
    x = netret(build(w_)); print(f'   win {w_:3d}: SR {x.mean()/x.std()*np.sqrt(252):+.2f}  net {x.mean()*1e4:+.2f} bps/d')

print('\n2. YEAR-BY-YEAR (window 20)')
for y,g in r.groupby(r.index.year):
    print(f'   {y}: {len(g):3d} sessions  net {g.mean()*1e4:+.2f} bps/d  SR {g.mean()/g.std()*np.sqrt(252):+.2f}')

print('\n3. NEWEY-WEST t-stat on mean daily net return (lag 10)')
x = r.values - 0; T=len(x); mu=x.mean(); e=x-mu
gam = [ (e[:T-k]*e[k:]).sum()/T for k in range(11)]
lrv = gam[0] + 2*sum((1-k/11)*gam[k] for k in range(1,11))
print(f'   mean {mu*1e4:+.3f} bps/d, NW t = {mu/np.sqrt(lrv/T):+.2f}')

print('\n4. PERMUTATION TEST: shuffle carry across assets within each day, 500 draws')
raw = P('carry_score').rolling(20,min_periods=1).mean(); rng=np.random.default_rng(0); sh=[]
base_sr = r.mean()/r.std()*np.sqrt(252)
for it in range(500):
    perm = pd.DataFrame(rng.permuted(raw.values, axis=1), index=raw.index, columns=raw.columns)
    S = sn(zs(perm))/vol20; Wp=(S.div(S.abs().sum(axis=1),axis=0)).fillna(0)
    xp = netret(Wp); sh.append(xp.mean()/xp.std()*np.sqrt(252))
sh=np.array(sh)
print(f'   actual SR {base_sr:+.2f} | null mean {sh.mean():+.2f} sd {sh.std():.2f} | p = {(sh>=base_sr).mean():.4f}')

print('\n5. STATIONARY BLOCK BOOTSTRAP of net returns (20-day blocks, 2000 draws)')
bs=[]
for it in range(2000):
    idx=[]
    while len(idx)<len(r):
        s=rng.integers(0,len(r)); idx.extend(range(s,min(s+20,len(r))))
    y=r.values[idx[:len(r)]]; bs.append(y.mean()/y.std()*np.sqrt(252))
bs=np.array(bs); print(f'   Sharpe 95% CI [{np.percentile(bs,2.5):+.2f}, {np.percentile(bs,97.5):+.2f}]  P(SR<0)={np.mean(bs<0):.3f}')

print('\n6. IS CARRY A DISGUISED RISK EXPOSURE?')
cz = sn(zs(raw))
for nm,X in [('realized_vol_20d',vol20),('spread_bps',spr),('liquidity_score',liq),('close',close)]:
    c=np.nanmean([cz.loc[t].corr(X.loc[t]) for t in cz.index]); print(f'   cross-sec corr(carry, {nm:17s}) = {c:+.3f}')
mkt = fwd.mean(axis=1); b = stats.linregress(mkt.reindex(r.index).fillna(0), r)
print(f'   beta of strategy to equal-weight market = {b.slope:+.4f} (t={b.slope/b.stderr:+.2f})')

print('\n7. ALPHA DECAY: carry IC at forward horizons')
for h in [1,5,20,60]:
    t_ = (close.shift(-h)/close-1); t_=t_.sub(t_.mean(axis=1),axis=0)
    ics=np.array([stats.spearmanr(cz.loc[dt],t_.loc[dt]).statistic for dt in cz.index[:-h]])
    ics=ics[np.isfinite(ics)]; print(f'   {h:2d}-day fwd: IC {ics.mean():+.4f}')
