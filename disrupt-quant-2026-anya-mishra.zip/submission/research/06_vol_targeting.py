import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
d = pd.read_csv('data/development.csv', parse_dates=['date']).sort_values(['date','asset_id'])
P=lambda c: d.pivot(index='date',columns='asset_id',values=c)
close,open_,spr,vol20,liq,volu=P('close'),P('open'),P('spread_bps'),P('realized_vol_20d'),P('liquidity_score'),P('volume')
fwd=close.shift(-1)/open_.shift(-1)-1; fwdx=fwd.sub(fwd.mean(axis=1),axis=0)
sect=d.groupby('asset_id').sector.first(); NAV=1e6
def zs(X): return X.sub(X.mean(axis=1),axis=0).div(X.std(axis=1),axis=0)
def sn(S):
    o=S.copy()
    for s in sect.unique():
        c=sect[sect==s].index; o[c]=S[c].sub(S[c].mean(axis=1),axis=0)
    return o
def netret(w):
    dlt=w.diff().fillna(w.iloc[0:1].reindex(w.index).fillna(0))
    part=(dlt.abs()*NAV/(volu*close)).clip(lower=0)
    cost=(dlt.abs()*(spr/20000+0.10*vol20*np.sqrt(part)/np.sqrt(liq.clip(.1,1.)))).sum(axis=1)
    return ((w*fwdx).sum(axis=1)-cost).dropna(), dlt.abs().sum(axis=1)
base = sn(zs(P('carry_score').rolling(5,min_periods=1).mean()))/vol20
base = base.div(base.abs().sum(axis=1),axis=0).fillna(0)

print('FIXED GROSS')
for g in [1.0,1.5,2.0]:
    r,t = netret(base*g)
    print(f'  gross {g}: ann {(1+r).prod()**(252/len(r))-1:6.2%} vol {r.std()*np.sqrt(252):5.2%} '
          f'SR {r.mean()/r.std()*np.sqrt(252):+.2f} maxDD {(np.cumprod(1+r)/np.maximum.accumulate(np.cumprod(1+r))-1).min():6.2%} turn {t.mean():.3f}')

print('\nVOL-TARGETED GROSS (ex-ante portfolio vol from 60d asset vols, cap 2.0)')
r1,_ = netret(base)
for tgt in [0.05,0.06,0.08]:
    ex_ante = (r1.rolling(60,min_periods=20).std()*np.sqrt(252)).shift(1).reindex(base.index).ffill().bfill()
    g = (tgt/ex_ante.clip(lower=1e-4)).clip(0.25,2.0)
    r,t = netret(base.mul(g,axis=0))
    nav=np.cumprod(1+r)
    print(f'  target {tgt:.0%}: ann {(1+r).prod()**(252/len(r))-1:6.2%} vol {r.std()*np.sqrt(252):5.2%} '
          f'SR {r.mean()/r.std()*np.sqrt(252):+.2f} maxDD {(nav/np.maximum.accumulate(nav)-1).min():6.2%} '
          f'turn {t.mean():.3f} avg gross {g.mean():.2f}')
