import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
from scipy import stats
dev = pd.read_csv('results/development/daily.csv', parse_dates=['date'])
r = dev.net_return

print('1. IS A 132-SESSION SHARPE OF -0.09 SURPRISING, GIVEN DEV?')
print(f'   dev Sharpe {r.mean()/r.std()*np.sqrt(252):.2f}; SE of a Sharpe estimated over 132 sessions '
      f'= sqrt(252/132) = {np.sqrt(252/132):.2f}')
roll = r.rolling(132)
rs = (roll.mean()/roll.std()*np.sqrt(252)).dropna()
print(f'   distribution of OVERLAPPING 132-session Sharpes within development:')
print(f'     min {rs.min():+.2f}  5th pct {rs.quantile(.05):+.2f}  median {rs.median():+.2f}  max {rs.max():+.2f}')
print(f'     fraction of dev 132-session windows with Sharpe <= -0.09: {(rs<=-0.09).mean():.1%}')

print('\n2. DID THE SIGNAL BREAK, OR DID THE BOOK JUST NOT PAY? Carry IC by period.')
d = pd.read_csv('data/development.csv', parse_dates=['date'])
v = pd.read_csv('data/validation.csv', parse_dates=['date'])
full = pd.concat([d,v], ignore_index=True).sort_values(['date','asset_id'])
P=lambda c: full.pivot(index='date',columns='asset_id',values=c)
close,open_ = P('close'),P('open')
fwd = close.shift(-1)/open_.shift(-1)-1; fwdx=fwd.sub(fwd.mean(axis=1),axis=0)
sect = full.groupby('asset_id').sector.first()
cz = P('carry_score').rolling(5,min_periods=1).mean()
cz = cz.sub(cz.mean(axis=1),axis=0).div(cz.std(axis=1),axis=0)
o=cz.copy()
for s in sect.unique():
    c=sect[sect==s].index; o[c]=cz[c].sub(cz[c].mean(axis=1),axis=0)
ic = pd.Series({t: stats.spearmanr(o.loc[t], fwdx.loc[t]).statistic for t in o.index[:-1]})
ic = ic[np.isfinite(ic)]
for lbl, m in [('dev 2021',ic.index.year==2021),('dev 2022',ic.index.year==2022),
               ('dev 2023',ic.index.year==2023),('dev 2024 H1',(ic.index.year==2024)&(ic.index<'2024-07-01')),
               ('VALIDATION 2024 H2',ic.index>='2024-07-01')]:
    x=ic[m]; print(f'   {lbl:20s} n={len(x):3d}  meanIC {x.mean():+.4f}  t={x.mean()/(x.std()/np.sqrt(len(x))):+5.2f}')

print('\n3. VALIDATION P&L ATTRIBUTION')
att = pd.read_csv('results/validation/attribution.csv', parse_dates=['date'])
bysec = att.groupby('sector').net_contribution.sum()*100
print('   net contribution by sector (% of NAV):')
for s,vv in bysec.sort_values().items(): print(f'     {s:14s} {vv:+.2f}%')
print(f'   total gross P&L {att.gross_contribution.sum()*100:+.2f}%  total costs {att.cost_contribution.sum()*100:.2f}%')
