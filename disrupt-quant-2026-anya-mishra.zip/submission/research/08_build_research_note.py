from reportlab.lib.pagesizes import LETTER
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                TableStyle, PageBreak, Image)

ACCENT = colors.HexColor("#1a3a5c")
GREY = colors.HexColor("#5a5a5a")

body = ParagraphStyle("body", fontName="Helvetica", fontSize=8.3, leading=10.3,
                      alignment=TA_JUSTIFY, spaceAfter=4.5)
h1 = ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=9.6, leading=11.5,
                    textColor=ACCENT, spaceBefore=5, spaceAfter=2.5)
title = ParagraphStyle("title", fontName="Helvetica-Bold", fontSize=13.5,
                       leading=16, textColor=ACCENT)
sub = ParagraphStyle("sub", fontName="Helvetica", fontSize=8.4, leading=10.5,
                     textColor=GREY, spaceAfter=7)
cap = ParagraphStyle("cap", fontName="Helvetica-Oblique", fontSize=7.4,
                     leading=9, textColor=GREY, spaceBefore=2, spaceAfter=6)

def tbl(data, widths, align_right_from=1, size=7.6):
    t = Table(data, colWidths=widths, hAlign="LEFT")
    t.setStyle(TableStyle([
        ("FONT", (0, 0), (-1, 0), "Helvetica-Bold", size),
        ("FONT", (0, 1), (-1, -1), "Helvetica", size),
        ("TEXTCOLOR", (0, 0), (-1, 0), ACCENT),
        ("LINEBELOW", (0, 0), (-1, 0), 0.6, ACCENT),
        ("LINEBELOW", (0, -1), (-1, -1), 0.4, colors.HexColor("#b8b8b8")),
        ("ALIGN", (align_right_from, 0), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 1.4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 1.4),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3),
    ]))
    return t

S = []
S.append(Paragraph("Sector-Neutral Carry in a Synthetic Cross-Section", title))
S.append(Paragraph("Disrupt Quant 2026 Challenge &nbsp;|&nbsp; Anya Mishra &nbsp;|&nbsp; "
                   "Development 2021-01-01 to 2024-06-28 &nbsp;|&nbsp; "
                   "Public validation 2024-07-01 to 2024-12-31", sub))

# ---------------- 1. Hypothesis
S.append(Paragraph("1. Hypothesis", h1))
S.append(Paragraph(
    "Within a sector, assets with a higher <b>carry_score</b> earn a higher subsequent return than their "
    "sector peers. I read carry_score as a slowly varying holding yield: a characteristic that compensates "
    "an investor for bearing something unattractive about the asset, rather than a price-history effect. "
    "Two implications follow and both are testable. First, the premium should be a <i>relative-value</i> "
    "effect inside a peer group, since the compensation is only meaningful against comparable assets; the "
    "sector-average level of carry should carry no information. Second, because a yield accrues with time "
    "held, predictive power should <i>grow</i> with the forecast horizon rather than decay, which is the "
    "opposite of what a microstructure or liquidity-provision effect would do.", body))

# ---------------- 2. Evidence
S.append(Paragraph("2. Evidence, including what failed", h1))
S.append(Paragraph(
    "I scanned all 18 candidate features by daily cross-sectional Spearman rank IC against the return the "
    "engine actually pays a new position (open t+1 to close t+1), with the target cross-sectionally demeaned "
    "so that no signal is rewarded for market beta. One IC per session gives 910 quasi-independent draws.", body))
S.append(tbl([
    ["Signal", "mean IC", "t-stat", "Verdict"],
    ["return_1d (reversal)", "-0.0475", "-6.54", "Real, but untradeable - see Costs"],
    ["carry_score", "+0.0238", "+3.42", "Retained"],
    ["return_5d (reversal)", "-0.0177", "-2.59", "0.43 correlated with return_1d; redundant"],
    ["return_20d (momentum)", "+0.0129", "+1.83", "Rejected: quintile spread is 0.01 bps"],
    ["14 others", "< |0.01|", "< |1.4|", "No content (sentiment, flow, macro 1-3, ...)"],
], [1.32*inch, 0.62*inch, 0.52*inch, 3.24*inch], 1))
S.append(Paragraph(
    "Both predictions of the hypothesis hold. Decomposing carry into a within-sector part and a "
    "sector-average part, <b>all</b> of the alpha sits in the within-sector component (IC +0.0270, t = +3.97) "
    "and none in the sector-average component (IC -0.0019, t = -0.24). And the IC rises monotonically with "
    "horizon: +0.018 at 1 day, +0.039 at 5, +0.063 at 20, +0.084 at 60. By contrast the reversal signal is "
    "entirely gone by t+2 (IC +0.009, t = 1.32), confirming the two effects are different in kind.", body))
S.append(Paragraph(
    "Conflicting evidence I am not discounting: the development IC strengthens materially through the sample "
    "(2021 t = 1.05, 2022 t = 1.84, 2023 t = 3.62, 2024 H1 t = 1.72). The full-sample t-statistic is therefore "
    "flattered by the middle of the period. I kept the signal because the sign is stable in every year and "
    "because the sector decomposition is a structural result, not a period-specific one, but the effect size "
    "is plainly uncertain.", body))

# ---------------- 3. Construction
S.append(Paragraph("3. From signal to positions", h1))
S.append(Paragraph(
    "<b>5-day mean of carry_score &rarr; cross-sectional z-score &rarr; demean within sector &rarr; divide by "
    "realized_vol_20d &rarr; normalise to gross 1 &rarr; scale to a 6% ex-ante annualised volatility target.</b> "
    "Ex-ante volatility is w'&Sigma;w from a 60-session sample covariance of asset returns, so leverage responds "
    "to the correlation structure rather than to individual volatilities alone. Leverage is clipped to "
    "[0.25, 2.0] and weights to &plusmn;19%.", body))
S.append(Paragraph(
    "There are only three free parameters and none was optimised to a peak. The smoothing window was chosen at "
    "5 sessions from a sensitivity sweep in which every setting from 1 to 90 sessions produced a development "
    "Sharpe between 1.30 and 1.57 - the choice is inside a flat region rather than on a spike. The covariance "
    "window (60) and the volatility target (6%) are risk-management settings, not return settings: across "
    "targets of 5%, 6% and 8% the Sharpe moves only between 1.59 and 1.61, because both alpha and cost scale "
    "close to linearly in position size. Selection experiments used an internal chronological split "
    "(fit 2021-2022, check 2023-2024 H1), never a shuffled split.", body))

S.append(Spacer(1, 4))
S.append(Image("research/fig.png", width=7.26*inch, height=2.07*inch))
S.append(Paragraph("Left: cumulative net return, development and the once-only frozen validation run. Centre: the distribution of 132-session Sharpe ratios inside development, against the realised validation Sharpe. Right: validation attribution - five of six sectors positive.", cap))
S.append(PageBreak())

# ---------------- 4. Risk
S.append(Paragraph("4. Risk, sizing and diversification", h1))
S.append(Paragraph(
    "The book is dollar-neutral and sector-neutral <i>by construction</i>, not by clipping: mean net exposure "
    "over development is 5&times;10<super>-10</super> and the engine records <b>zero constraint-adjustment days</b> "
    "in both periods. This matters mechanically, because the engine responds to a breach by scaling the entire "
    "weight vector down rather than repairing the offending leg. Inverse-volatility weighting equalises risk "
    "rather than dollars across the 24 names; average gross exposure is 1.34 against a 2.0 limit, leaving "
    "headroom for the volatility scaler. Measured beta to the equal-weight universe is +0.0099 (t = 0.70), so "
    "essentially none of the return is directional. Maximum drawdown on development is -3.46% against 6.08% "
    "realised volatility.", body))
S.append(Paragraph(
    "Expected failure conditions: (i) carry stops being compensated and becomes a pure risk marker, in which "
    "case the premium disappears without warning; (ii) a shock that is common to the high-carry names across "
    "several sectors at once, which sector-neutrality does not hedge; (iii) a persistent widening of spreads, "
    "which would raise the cost floor under a signal whose gross edge is only ~2.3 bps/day. Financing and "
    "stock-borrow costs are excluded by the assessment convention. This flatters a long/short book more than a "
    "long-only one, and at an average gross of 1.34 a realistic borrow charge would reduce the reported return, "
    "though it would not change the sign of the result.", body))

# ---------------- 5. Costs
S.append(Paragraph("5. Costs and their effect on design", h1))
S.append(Paragraph(
    "Costs are the reason this is a carry strategy and not a reversal strategy, and that was the single most "
    "consequential finding in the research. Reversal is by far the stronger statistical signal, but its "
    "cross-sectional score has day-over-day autocorrelation of <b>-0.04</b>: it reinvents itself every session, "
    "forcing ~146% of NAV of turnover per day. Gross alpha of 5.9 bps/day is then consumed by 7.1 bps/day of "
    "cost. Because spread dominates impact at this NAV, cost is close to linear in trade size, so scaling the "
    "book down cannot rescue it - both sides shrink together. I tested tail-only construction (top/bottom 2 to "
    "8 names), spread-weighted cost-aware scoring, and no-trade bands of 2 to 6%; every variant remained "
    "negative net on both halves of the split. I report reversal as a rejected hypothesis rather than omitting it.", body))
S.append(Paragraph(
    "Carry's score, by contrast, has autocorrelation +0.994. It trades ~9.5% of NAV per day, costs ~0.5 bps/day "
    "against ~2.3 bps/day of gross alpha, and therefore keeps roughly 80% of its edge. The 5-day smoothing was "
    "adopted partly for this reason: it cut turnover by half while slightly <i>improving</i> Sharpe on both "
    "halves of the internal split.", body))
S.append(tbl([
    ["Cost multiplier", "1.0x", "1.5x", "2.0x", "3.0x"],
    ["Development Sharpe", "1.38", "1.29", "1.19", "1.00"],
    ["Development ann. return", "8.57%", "7.94%", "7.31%", "6.06%"],
    ["Validation Sharpe", "-0.09", "-0.20", "-0.31", "n/a"],
], [1.7*inch, 0.72*inch, 0.72*inch, 0.72*inch, 0.72*inch], 1))
S.append(Paragraph("Sensitivity check: strategy decisions held fixed, NAV and trade sizes recomputed.", cap))

# ---------------- 6. Validation
S.append(Paragraph("6. Development versus validation", h1))
S.append(tbl([
    ["", "Sessions", "Ann. return", "Ann. vol", "Sharpe", "Max DD", "Calmar", "Turnover", "Adj. days"],
    ["Development", "910", "8.57%", "6.08%", "1.38", "-3.46%", "2.48", "24.0x", "0"],
    ["Public validation", "132", "-0.78%", "6.25%", "-0.09", "-5.06%", "-0.15", "27.6x", "0"],
], [1.14*inch, 0.56*inch, 0.72*inch, 0.56*inch, 0.5*inch, 0.56*inch, 0.52*inch, 0.66*inch, 0.6*inch], 1))
S.append(Paragraph(
    "<b>The strategy was frozen before validation was run, validation was run once, and nothing has been changed "
    "since.</b> The result is flat to slightly negative and I am reporting it as it came out. Three diagnostics "
    "bear on whether it represents a broken signal or a small sample. First, the standard error of a Sharpe "
    "estimated over 132 sessions is sqrt(252/132) = 1.38, so the validation figure sits roughly 1.1 standard "
    "errors below the development estimate; within development itself, 4.6% of overlapping 132-session windows "
    "produced a Sharpe at or below -0.09. Second, the signal went quiet rather than inverting: validation carry "
    "IC was -0.0135 with t = -0.74, statistically indistinguishable from zero. Third, attribution is highly "
    "concentrated - Energy contributed -2.82% while all five remaining sectors were positive, together "
    "contributing +2.51%. Energy was only 21% of average gross exposure, so this was signal failure in one "
    "sector rather than a sizing failure, which is precisely why I did not add a sector risk cap in response. "
    "Doing so would fit a control to a single observed loss and would convert validation into development.", body))

# ---------------- 7. Limitations
S.append(Paragraph("7. Limitations and overfitting risk", h1))
S.append(Paragraph(
    "The honest summary is that one signal out of eighteen survived, and the surviving signal is weak. Selecting "
    "the best of eighteen candidates inflates the apparent t-statistic even with an in-sample permutation test "
    "clearing at p &lt; 0.002 (actual Sharpe +1.41 versus a null of -5.53 &plusmn; 0.57 from 500 within-day "
    "shuffles of carry), and a 20-day block bootstrap giving a 95% Sharpe interval of [+0.58, +2.26]. Those "
    "tests establish that the development result is not an artifact of the portfolio machinery; they cannot "
    "establish that the effect persists. The rising IC through development and the flat validation are jointly "
    "more consistent with a true Sharpe well below 1.38 - plausibly 0.3 to 0.7 - than with the development point "
    "estimate. Gross edge of ~2.3 bps/day is thin enough that a doubling of spreads or a halving of the premium "
    "would put the strategy at breakeven. Finally, carry_score has no economic definition I can verify, so I "
    "cannot rule out a relationship that is regime-switched by construction.", body))

# ---------------- 8. Next step
S.append(Paragraph("8. Single most useful next investigation", h1))
S.append(Paragraph(
    "Determine whether the carry premium is <i>conditional</i> rather than constant. The specific test: estimate "
    "the within-sector carry IC in rolling 120-session windows across the full development sample and regress it "
    "on contemporaneous state variables - cross-sectional dispersion of carry, average realized volatility, and "
    "sector_dispersion. If the premium is systematically larger when carry dispersion is wide, that both explains "
    "the 2021-to-2023 strengthening and the 2024 H2 flatness, and yields an implementable rule: size the book in "
    "proportion to the dispersion of the signal and stand down when the cross-section is compressed. If no state "
    "variable predicts the IC, the conclusion is that the premium is constant but small and the development "
    "Sharpe was a favourable draw - which argues for running this at materially lower risk, or not at all.", body))

doc = SimpleDocTemplate(
    "research_note.pdf",
    pagesize=LETTER, leftMargin=0.62*inch, rightMargin=0.62*inch,
    topMargin=0.5*inch, bottomMargin=0.45*inch,
    title="Sector-Neutral Carry in a Synthetic Cross-Section",
    author="Anya Mishra")
doc.build(S)
print("built")
